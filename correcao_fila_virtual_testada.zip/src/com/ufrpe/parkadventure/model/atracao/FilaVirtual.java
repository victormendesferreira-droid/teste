package com.ufrpe.parkadventure.model.atracao;

import com.ufrpe.parkadventure.model.pessoa.Visitante;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

// Fura-fila FÍSICO: o visitante reserva um horário; no dia, apresenta-se ao operador
// dentro da janela [horário, horário + TOLERANCIA] e passa na frente da fila comum.
public class FilaVirtual {
    public enum ResultadoReserva { OK, HORARIO_INVALIDO, JA_RESERVOU_NESTA_ATRACAO, HORARIO_CHEIO }

    public static final Duration TOLERANCIA = Duration.ofMinutes(15);
    private static final LocalTime ABERTURA = LocalTime.of(11, 0);
    private static final LocalTime FECHAMENTO = LocalTime.of(18, 0);

    private final int vagasPorHorario;
    private final List<Reserva> reservas = new ArrayList<>();

    public FilaVirtual(int vagasPorHorario) { this.vagasPorHorario = vagasPorHorario; }

    // Única fonte dos horários (a tela e a validação usam esta lista)
    public static List<LocalTime> horarios() {
        List<LocalTime> lista = new ArrayList<>();
        for (LocalTime h = ABERTURA; !h.isAfter(FECHAMENTO); h = h.plusMinutes(30)) lista.add(h);
        return lista;
    }

    public static boolean horarioValido(LocalTime h) { return h != null && horarios().contains(h); }

    public ResultadoReserva reservar(Visitante v, LocalDate data, LocalTime horario) {
        if (v == null || data == null || !horarioValido(horario)) return ResultadoReserva.HORARIO_INVALIDO;
        if (reservaAtiva(v, data) != null) return ResultadoReserva.JA_RESERVOU_NESTA_ATRACAO;
        if (vagasRestantes(data, horario) <= 0) return ResultadoReserva.HORARIO_CHEIO;
        reservas.add(new Reserva(v, data, horario));
        return ResultadoReserva.OK;
    }

    public boolean cancelar(Visitante v, LocalDate data) {
        Reserva r = reservaAtiva(v, data);
        if (r == null) return false;
        r.marcar(EstadoReserva.CANCELADA);
        return true;
    }

    public Reserva reservaAtiva(Visitante v, LocalDate data) {
        for (Reserva r : reservas)
            if (r.estaAtiva() && r.getVisitante() == v && r.getData().equals(data)) return r;
        return null;
    }

    public boolean temReservaEm(Visitante v, LocalDate data, LocalTime horario) {
        Reserva r = reservaAtiva(v, data);
        return r != null && r.getHorario().equals(horario);
    }

    public int vagasRestantes(LocalDate data, LocalTime horario) {
        long usadas = reservas.stream()
                .filter(r -> r.estaAtiva() && r.getData().equals(data) && r.getHorario().equals(horario))
                .count();
        return vagasPorHorario - (int) usadas;
    }

    // Reserva que PODE passar agora: ativa e dentro da janela. null se não pode.
    public Reserva elegivel(Visitante v, LocalDateTime agora) {
        Reserva r = reservaAtiva(v, agora.toLocalDate());
        if (r == null) return null;
        LocalDateTime inicio = LocalDateTime.of(r.getData(), r.getHorario());
        boolean dentro = !agora.isBefore(inicio) && !agora.isAfter(inicio.plus(TOLERANCIA));
        return dentro ? r : null;
    }

    public void marcarUsada(Reserva r) { r.marcar(EstadoReserva.USADA); }

    // Quem passou da tolerância sem aparecer vira NO_SHOW (libera a "cabeça" da fila)
    public int expirarNoShows(LocalDateTime agora) {
        int n = 0;
        for (Reserva r : reservas) {
            LocalDateTime fim = LocalDateTime.of(r.getData(), r.getHorario()).plus(TOLERANCIA);
            if (r.estaAtiva() && agora.isAfter(fim)) { r.marcar(EstadoReserva.NO_SHOW); n++; }
        }
        return n;
    }

    // Quem o operador pode esperar agora, em ordem de horário
    public List<Reserva> chamadaAtual(LocalDateTime agora) {
        List<Reserva> lista = new ArrayList<>();
        for (Reserva r : reservas) if (elegivel(r.getVisitante(), agora) == r) lista.add(r);
        lista.sort(Comparator.comparing(Reserva::getHorario));
        return lista;
    }

    public int totalAtivas(LocalDate data) {
        return (int) reservas.stream().filter(r -> r.estaAtiva() && r.getData().equals(data)).count();
    }
}
