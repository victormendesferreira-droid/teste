package com.ufrpe.parkadventure.model.atracao;

public enum EstadoReserva { RESERVADA, USADA, NO_SHOW, CANCELADA }
