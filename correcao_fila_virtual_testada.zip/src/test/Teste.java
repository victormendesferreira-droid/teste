import com.ufrpe.parkadventure.model.atracao.*;
import com.ufrpe.parkadventure.model.atracao.FilaVirtual.ResultadoReserva;
import com.ufrpe.parkadventure.model.pessoa.Visitante;
import java.time.*;

public class Teste {
    static int ok = 0, falhas = 0;
    static void conferir(String nome, boolean cond) {
        if (cond) ok++; else { falhas++; System.out.println("FALHOU: " + nome); }
    }
    public static void main(String[] a) {
        FilaVirtual f = new FilaVirtual(2);
        Visitante ana = new Visitante("Ana", "15/05/2001", null, 165);
        Visitante bia = new Visitante("Bia", "15/05/2001", null, 165);
        Visitante caio = new Visitante("Caio", "15/05/2001", null, 170);
        LocalDate dia = LocalDate.of(2026, 11, 8);
        LocalTime h14 = LocalTime.of(14, 0);

        conferir("horarios 15 itens", FilaVirtual.horarios().size() == 15);
        conferir("horario invalido 10:00", f.reservar(ana, dia, LocalTime.of(10, 0)) == ResultadoReserva.HORARIO_INVALIDO);
        conferir("horario invalido 14:10", f.reservar(ana, dia, LocalTime.of(14, 10)) == ResultadoReserva.HORARIO_INVALIDO);
        conferir("reserva ok", f.reservar(ana, dia, h14) == ResultadoReserva.OK);
        conferir("duplicada no mesmo dia", f.reservar(ana, dia, LocalTime.of(15, 0)) == ResultadoReserva.JA_RESERVOU_NESTA_ATRACAO);
        conferir("outro dia pode", f.reservar(ana, dia.plusDays(1), h14) == ResultadoReserva.OK);
        conferir("2a vaga", f.reservar(bia, dia, h14) == ResultadoReserva.OK);
        conferir("horario cheio", f.reservar(caio, dia, h14) == ResultadoReserva.HORARIO_CHEIO);
        conferir("vagas restantes 0", f.vagasRestantes(dia, h14) == 0);

        // janela: ANTES do horário não passa (bug original: passava a qualquer hora)
        conferir("antes da janela", f.elegivel(ana, LocalDateTime.of(dia, LocalTime.of(11, 5))) == null);
        conferir("na janela", f.elegivel(ana, LocalDateTime.of(dia, LocalTime.of(14, 10))) != null);
        conferir("limite da tolerancia", f.elegivel(ana, LocalDateTime.of(dia, LocalTime.of(14, 15))) != null);
        conferir("apos tolerancia", f.elegivel(ana, LocalDateTime.of(dia, LocalTime.of(14, 16))) == null);
        conferir("outro dia nao vale", f.elegivel(ana, LocalDateTime.of(dia.plusDays(2), h14)) == null);

        // chamada atual
        conferir("chamada tem 2", f.chamadaAtual(LocalDateTime.of(dia, LocalTime.of(14, 5))).size() == 2);

        // uso + no-show
        Reserva r = f.elegivel(ana, LocalDateTime.of(dia, LocalTime.of(14, 5)));
        f.marcarUsada(r);
        conferir("usada nao e mais ativa", !r.estaAtiva() && f.reservaAtiva(ana, dia) == null);
        conferir("usada libera cabeça", f.chamadaAtual(LocalDateTime.of(dia, LocalTime.of(14, 5))).size() == 1);
        conferir("no-show expira 1", f.expirarNoShows(LocalDateTime.of(dia, LocalTime.of(14, 30))) == 1);
        conferir("bia virou no-show", f.reservaAtiva(bia, dia) == null);
        conferir("vaga do no-show reabre", f.vagasRestantes(dia, h14) == 2);

        // cancelamento
        FilaVirtual g = new FilaVirtual(1);
        g.reservar(caio, dia, h14);
        conferir("cancela", g.cancelar(caio, dia));
        conferir("cancela de novo falha", !g.cancelar(caio, dia));
        conferir("reabre vaga", g.vagasRestantes(dia, h14) == 1);
        conferir("pode reservar de novo", g.reservar(caio, dia, h14) == ResultadoReserva.OK);

        System.out.println("OK=" + ok + " FALHAS=" + falhas);
        if (falhas > 0) System.exit(1);
    }
}
